from django.contrib import admin

from .models import Reserva, ReservaChave


class ReservaChaveInline(admin.TabularInline):
	model = ReservaChave
	extra = 1
	fields = ('copia_chave', 'data_inicio', 'horario_inicio', 'data_fim', 'horario_fim', 'status')


@admin.register(Reserva)
class ReservaAdmin(admin.ModelAdmin):
	list_display = ('id', 'usuario', 'data_inicio', 'horario_inicio', 'data_fim', 'horario_fim', 'status')
	list_filter = ('status', 'data_inicio')
	search_fields = ('usuario__username', 'usuario__email')
	inlines = [ReservaChaveInline]


@admin.register(ReservaChave)
class ReservaChaveAdmin(admin.ModelAdmin):
	list_display = ('reserva', 'copia_chave', 'data_inicio', 'data_fim', 'status')
	list_filter = ('status', 'data_inicio')
	search_fields = ('reserva__id', 'copia_chave__id')
