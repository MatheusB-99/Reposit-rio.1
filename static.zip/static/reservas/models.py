from django.conf import settings
from django.db import models


class Reserva(models.Model):
    STATUS_CHOICES = [
        ('aberta', 'Aberta'),
        ('confirmada', 'Confirmada'),
        ('cancelada', 'Cancelada'),
        ('atrasada', 'Atrasada'),
    ]
    
    usuario = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='reservas_modulo')
    copias_chave = models.ManyToManyField('copias.CopiaChave', through='ReservaChave', related_name='reservas_set')
    data_inicio = models.DateField(null=True, blank=True)
    horario_inicio = models.TimeField(null=True, blank=True)
    data_fim = models.DateField(null=True, blank=True)
    horario_fim = models.TimeField(null=True, blank=True)
    data = models.DateField(null=True, blank=True)
    horario = models.TimeField(null=True, blank=True)
    status = models.CharField(max_length=15, choices=STATUS_CHOICES)
    notificado_vencimento = models.BooleanField(default=False)
    notificado_atraso = models.BooleanField(default=False)

    class Meta:
        db_table = 'reservas_reserva'

    def save(self, *args, **kwargs):
        if self.data_inicio and not self.data:
            self.data = self.data_inicio
        if self.horario_inicio and not self.horario:
            self.horario = self.horario_inicio
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Reserva {self.id}"


class ReservaChave(models.Model):
    STATUS_CHOICES = [
        ('reservada', 'Reservada'),
        ('confirmada', 'Confirmada'),
        ('cancelada', 'Cancelada'),
        ('atrasada', 'Atrasada'),
    ]
    
    reserva = models.ForeignKey(Reserva, on_delete=models.CASCADE, related_name='reservaChave_set')
    copia_chave = models.ForeignKey('copias.CopiaChave', on_delete=models.PROTECT, related_name='reserva_chaves')
    data_inicio = models.DateField()
    horario_inicio = models.TimeField(null=True, blank=True)
    data_fim = models.DateField()
    horario_fim = models.TimeField(null=True, blank=True)
    status = models.CharField(max_length=15, choices=STATUS_CHOICES, default='reservada')
    notificado_vencimento = models.BooleanField(default=False)
    notificado_atraso = models.BooleanField(default=False)

    class Meta:
        unique_together = ('reserva', 'copia_chave')
        verbose_name_plural = 'Reserva Chaves'

    def __str__(self):
        return f"{self.reserva} - {self.copia_chave}"