from django.contrib import messages
from django.urls import reverse_lazy
from django.views.generic import CreateView, DeleteView, ListView, UpdateView
from django.contrib.messages.views import SuccessMessageMixin
from django.conf import settings
from django.template.loader import render_to_string
from django.core.mail import send_mail
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.db.models import Q

from .forms import ReservaForm, ReservaChaveFormSet
from django.utils import timezone
from datetime import datetime
from .models import Reserva


class ReservasView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    permission_required = 'reservas.view_reserva'
    model = Reserva
    template_name = 'reservas.html'
    paginate_by = 8

    def get_queryset(self):
        buscar = self.request.GET.get('buscar')
        qs = super().get_queryset().select_related('usuario').prefetch_related('copias_chave')
        if buscar:
            return qs.filter(
                Q(usuario__username__icontains=buscar)
                | Q(usuario__email__icontains=buscar)
                | Q(usuario__first_name__icontains=buscar)
                | Q(usuario__last_name__icontains=buscar)
            )
        return qs


class ReservaEmailMixin:
    def _get_reserva_email_data(self, reserva):
        email = [reserva.usuario.email]
        descricao = []
        chaves_list = reserva.copias_chave.all()
        
        for copia_chave in chaves_list:
            if copia_chave and copia_chave.chave:
                chave = copia_chave.chave
                descricao.append(f'Chave: {chave}')
                if chave.tipo == 'sala' and chave.sala:
                    descricao.append(f'Sala: {chave.sala}')
                elif chave.tipo == 'predio' and chave.predio:
                    descricao.append(f'Prédio: {chave.predio}')

        copias_str = ', '.join([str(c) for c in chaves_list]) if chaves_list else 'N/A'
        dados = {
            'cliente': reserva.usuario.get_full_name() or reserva.usuario.username,
            'email': reserva.usuario.email,
            'id_reserva': reserva.id,
            'data_inicio': reserva.data_inicio.strftime('%d/%m/%Y') if reserva.data_inicio else '',
            'horario_inicio': reserva.horario_inicio.strftime('%H:%M') if reserva.horario_inicio else '',
            'data_fim': reserva.data_fim.strftime('%d/%m/%Y') if reserva.data_fim else '',
            'horario_fim': reserva.horario_fim.strftime('%H:%M') if reserva.horario_fim else '',
            'copia_chave': copias_str,
            'status': reserva.get_status_display(),
            'descricao': descricao,
        }
        return email, dados

    def _send_reserva_email(self, subject, reserva):
        email, dados = self._get_reserva_email_data(reserva)
        texto_email = render_to_string(template_name='emails/texto_email.txt', context=dados)
        html_email = render_to_string(template_name='emails/texto_email.html', context=dados)

        send_mail(
            subject=subject,
            message=texto_email,
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=email,
            html_message=html_email,
            fail_silently=True,
        )


class ReservaCreateView(LoginRequiredMixin, PermissionRequiredMixin, ReservaEmailMixin, SuccessMessageMixin, CreateView):
    permission_required = 'reservas.add_reserva'
    model = Reserva
    form_class = ReservaForm
    template_name = 'reserva_form.html'
    success_url = reverse_lazy('reservas')
    success_message = 'Reserva cadastrada com sucesso!'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        if self.request.POST:
            context['chaves_formset'] = ReservaChaveFormSet(self.request.POST, instance=self.object)
        else:
            context['chaves_formset'] = ReservaChaveFormSet(instance=self.object)
        return context

    def form_valid(self, form):
        context = self.get_context_data()
        chaves_formset = context['chaves_formset']
        
        if chaves_formset.is_valid():
            response = super().form_valid(form)
            chaves_formset.instance = self.object
            chaves_formset.save()
            reserva = self.object
            # Atualiza data_fim/horario_fim do mestre com o máximo entre as chaves (como nos slides)
            venc_dt = None
            for c in reserva.reservaChave_set.all():
                if c.data_fim and c.horario_fim:
                    dt = datetime.combine(c.data_fim, c.horario_fim)
                    try:
                        dt = timezone.make_aware(dt)
                    except Exception:
                        pass
                    if not venc_dt or dt > venc_dt:
                        venc_dt = dt
            if venc_dt:
                reserva.data_fim = venc_dt.date()
                reserva.horario_fim = venc_dt.time()
                reserva.save(update_fields=['data_fim', 'horario_fim'])
            try:
                self._send_reserva_email('Confirmação de Reserva - ChaveMaster', reserva)
            except Exception:
                pass
            return response
        else:
            return self.form_invalid(form)


class ReservaUpdateView(LoginRequiredMixin, PermissionRequiredMixin, ReservaEmailMixin, SuccessMessageMixin, UpdateView):
    permission_required = 'reservas.change_reserva'
    model = Reserva
    form_class = ReservaForm
    template_name = 'reserva_form.html'
    success_url = reverse_lazy('reservas')
    success_message = 'Reserva alterada com sucesso!'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        if self.request.POST:
            context['chaves_formset'] = ReservaChaveFormSet(self.request.POST, instance=self.object)
        else:
            context['chaves_formset'] = ReservaChaveFormSet(instance=self.object)
        return context

    def form_valid(self, form):
        context = self.get_context_data()
        chaves_formset = context['chaves_formset']
        
        if chaves_formset.is_valid():
            response = super().form_valid(form)
            chaves_formset.instance = self.object
            chaves_formset.save()
            reserva = self.object
            # Atualiza data_fim/horario_fim do mestre com o máximo entre as chaves (como nos slides)
            venc_dt = None
            for c in reserva.reservaChave_set.all():
                if c.data_fim and c.horario_fim:
                    dt = datetime.combine(c.data_fim, c.horario_fim)
                    try:
                        dt = timezone.make_aware(dt)
                    except Exception:
                        pass
                    if not venc_dt or dt > venc_dt:
                        venc_dt = dt
            if venc_dt:
                reserva.data_fim = venc_dt.date()
                reserva.horario_fim = venc_dt.time()
                reserva.save(update_fields=['data_fim', 'horario_fim'])
            try:
                self._send_reserva_email('Reserva Atualizada - ChaveMaster', reserva)
            except Exception:
                pass
            return response
        else:
            return self.form_invalid(form)


class ReservaDeleteView(LoginRequiredMixin, PermissionRequiredMixin, ReservaEmailMixin, DeleteView):
    permission_required = 'reservas.delete_reserva'
    model = Reserva
    template_name = 'reserva_confirm_delete.html'
    success_url = reverse_lazy('reservas')

    def delete(self, request, *args, **kwargs):
        reserva = self.get_object()
        try:
            self._send_reserva_email('Reserva Cancelada - ChaveMaster', reserva)
        except Exception:
            pass
        messages.success(request, 'Reserva apagada com sucesso!')
        return super().delete(request, *args, **kwargs)
