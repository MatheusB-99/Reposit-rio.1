
from django.contrib import messages
from django.contrib.messages.views import SuccessMessageMixin
from django.urls import reverse_lazy
from django.views.generic import CreateView, DeleteView, ListView, UpdateView
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.db.models import Q

from .forms import EmprestimoForm, EmprestimoChaveFormSet
from .models import Emprestimo
from django.utils import timezone
from datetime import datetime


class EmprestimosView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    permission_required = 'emprestimos.view_emprestimo'
    model = Emprestimo
    template_name = 'emprestimos.html'
    paginate_by = 8

    def get_queryset(self):
        buscar = self.request.GET.get('buscar')
        qs = super().get_queryset().select_related('usuario', 'reserva').prefetch_related('copias_chave')
        if buscar:
            return qs.filter(
                Q(usuario__username__icontains=buscar)
                | Q(usuario__email__icontains=buscar)
                | Q(usuario__first_name__icontains=buscar)
                | Q(usuario__last_name__icontains=buscar)
            )
        return qs


class EmprestimoCreateView(LoginRequiredMixin, PermissionRequiredMixin, SuccessMessageMixin, CreateView):
    permission_required = 'emprestimos.add_emprestimo'
    model = Emprestimo
    form_class = EmprestimoForm
    template_name = 'emprestimo_form.html'
    success_url = reverse_lazy('emprestimos')
    success_message = 'Emprestimo cadastrado com sucesso!'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        if self.request.POST:
            context['chaves_formset'] = EmprestimoChaveFormSet(self.request.POST, instance=self.object)
        else:
            context['chaves_formset'] = EmprestimoChaveFormSet(instance=self.object)
        return context

    def form_valid(self, form):
        context = self.get_context_data()
        chaves_formset = context['chaves_formset']
        
        if chaves_formset.is_valid():
            response = super().form_valid(form)
            chaves_formset.instance = self.object
            chaves_formset.save()
            # Atualiza data_prevista/horario_prevista do mestre com o máximo entre as chaves
            emprestimo = self.object
            venc_dt = None
            for c in emprestimo.emprestimoChave_set.all():
                if c.data_prevista_devolucao and c.horario_prevista_devolucao:
                    dt = datetime.combine(c.data_prevista_devolucao, c.horario_prevista_devolucao)
                    try:
                        dt = timezone.make_aware(dt)
                    except Exception:
                        pass
                    if not venc_dt or dt > venc_dt:
                        venc_dt = dt
            if venc_dt:
                emprestimo.data_prevista = venc_dt.date()
                emprestimo.horario_prevista = venc_dt.time()
                emprestimo.save(update_fields=['data_prevista', 'horario_prevista'])
            return response
        else:
            return self.form_invalid(form)


class EmprestimoUpdateView(LoginRequiredMixin, PermissionRequiredMixin, SuccessMessageMixin, UpdateView):
    permission_required = 'emprestimos.change_emprestimo'
    model = Emprestimo
    form_class = EmprestimoForm
    template_name = 'emprestimo_form.html'
    success_url = reverse_lazy('emprestimos')
    success_message = 'Emprestimo alterado com sucesso!'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        if self.request.POST:
            context['chaves_formset'] = EmprestimoChaveFormSet(self.request.POST, instance=self.object)
        else:
            context['chaves_formset'] = EmprestimoChaveFormSet(instance=self.object)
        return context

    def form_valid(self, form):
        context = self.get_context_data()
        chaves_formset = context['chaves_formset']
        
        if chaves_formset.is_valid():
            response = super().form_valid(form)
            chaves_formset.instance = self.object
            chaves_formset.save()
            # Atualiza data_prevista/horario_prevista do mestre com o máximo entre as chaves
            emprestimo = self.object
            venc_dt = None
            for c in emprestimo.emprestimoChave_set.all():
                if c.data_prevista_devolucao and c.horario_prevista_devolucao:
                    dt = datetime.combine(c.data_prevista_devolucao, c.horario_prevista_devolucao)
                    try:
                        dt = timezone.make_aware(dt)
                    except Exception:
                        pass
                    if not venc_dt or dt > venc_dt:
                        venc_dt = dt
            if venc_dt:
                emprestimo.data_prevista = venc_dt.date()
                emprestimo.horario_prevista = venc_dt.time()
                emprestimo.save(update_fields=['data_prevista', 'horario_prevista'])
            return response
        else:
            return self.form_invalid(form)


class EmprestimoDeleteView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):
    permission_required = 'emprestimos.delete_emprestimo'
    model = Emprestimo
    template_name = 'emprestimo_confirm_delete.html'
    success_url = reverse_lazy('emprestimos')

    def delete(self, request, *args, **kwargs):
        messages.success(request, 'Emprestimo apagado com sucesso!')
        return super().delete(request, *args, **kwargs)
