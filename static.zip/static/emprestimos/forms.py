﻿from django import forms
from django.db.models import Q
from django.forms import inlineformset_factory
from copias.models import CopiaChave
from .models import Emprestimo, EmprestimoChave


class EmprestimoForm(forms.ModelForm):
    class Meta:
        model = Emprestimo
        fields = [
            'usuario',
            'reserva',
            'data_retirada',
            'horario_retirada',
            'data_prevista',
            'horario_prevista',
            'status',
        ]
        error_messages = {
            'usuario': {'required': 'O usuário do empréstimo é obrigatório'},
            'data_retirada': {'required': 'A data de retirada é obrigatória'},
            'horario_retirada': {'required': 'O horário de retirada é obrigatório'},
            'data_prevista': {'required': 'A data prevista é obrigatória'},
            'horario_prevista': {'required': 'O horário previsto é obrigatório'},
            'status': {'required': 'O status é obrigatório'},
        }

    def clean(self):
        cleaned_data = super().clean()
        data_retirada = cleaned_data.get('data_retirada')
        horario_retirada = cleaned_data.get('horario_retirada')
        data_prevista = cleaned_data.get('data_prevista')
        horario_prevista = cleaned_data.get('horario_prevista')

        if not data_retirada or not horario_retirada or not data_prevista or not horario_prevista:
            raise forms.ValidationError('Os campos de retirada e devolução prevista do empréstimo são obrigatórios.')

        if data_retirada > data_prevista or (data_retirada == data_prevista and horario_retirada >= horario_prevista):
            raise forms.ValidationError('A data e horário de devolução devem ser posteriores à retirada.')

        return cleaned_data


class EmprestimoChaveForm(forms.ModelForm):
    class Meta:
        model = EmprestimoChave
        fields = ['copia_chave', 'data_retirada', 'horario_retirada', 'data_prevista_devolucao', 'horario_prevista_devolucao', 'data_devolucao', 'horario_devolucao', 'status']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        available_qs = CopiaChave.objects.filter(chave__tipo='sala', status='disponivel')
        if self.instance.pk and self.instance.copia_chave_id:
            available_qs = CopiaChave.objects.filter(chave__tipo='sala').filter(
                Q(status='disponivel') | Q(pk=self.instance.copia_chave_id)
            )
        self.fields['copia_chave'].queryset = available_qs
        # Permitir deixar campos em branco para linhas vazias do formset
        self.fields['copia_chave'].required = False
        self.fields['data_retirada'].required = False
        self.fields['horario_retirada'].required = False
        self.fields['data_prevista_devolucao'].required = False
        self.fields['horario_prevista_devolucao'].required = False
        self.fields['data_devolucao'].required = False
        self.fields['horario_devolucao'].required = False
        self.fields['status'].required = False

    def clean(self):
        cleaned_data = super().clean()
        copia_chave = cleaned_data.get('copia_chave')
        data_retirada = cleaned_data.get('data_retirada')
        horario_retirada = cleaned_data.get('horario_retirada')
        data_prevista_devolucao = cleaned_data.get('data_prevista_devolucao')
        horario_prevista_devolucao = cleaned_data.get('horario_prevista_devolucao')
        status = cleaned_data.get('status')

        # Se copia_chave está preenchida, campos obrigatórios devem estar também
        if copia_chave:
            if not data_retirada:
                raise forms.ValidationError('Data de retirada é obrigatória se chave estiver selecionada.')
            if not horario_retirada:
                raise forms.ValidationError('Horário de retirada é obrigatório se chave estiver selecionada.')
            if not data_prevista_devolucao:
                raise forms.ValidationError('Data prevista de devolução é obrigatória se chave estiver selecionada.')
            if not horario_prevista_devolucao:
                raise forms.ValidationError('Horário previsto de devolução é obrigatório se chave estiver selecionada.')
            if not status:
                raise forms.ValidationError('Status é obrigatório se chave estiver selecionada.')

            # Validar que data_prevista_devolucao >= data_retirada
            if data_retirada > data_prevista_devolucao:
                raise forms.ValidationError('Data prevista de devolução deve ser maior ou igual à data de retirada.')

        return cleaned_data

    def clean_copia_chave(self):
        copia_chave = self.cleaned_data.get('copia_chave')
        if copia_chave and copia_chave.chave.tipo == 'predio':
            raise forms.ValidationError('Chave de prédio não pode ser emprestada.')
        if copia_chave and self.instance.pk and self.instance.copia_chave_id == copia_chave.pk:
            return copia_chave
        if copia_chave and copia_chave.status != 'disponivel':
            raise forms.ValidationError('Cópia de chave não está disponível.')
        if copia_chave and copia_chave.em_ultima_disponivel():
            raise forms.ValidationError('Esta é a única cópia disponível desta chave; não pode ser emprestada.')
        if copia_chave and copia_chave.em_uso():
            raise forms.ValidationError('Esta cópia já está associada a uma reserva ou empréstimo ativo.')
        return copia_chave


EmprestimoChaveFormSet = inlineformset_factory(
    Emprestimo,
    EmprestimoChave,
    form=EmprestimoChaveForm,
    fields=('copia_chave', 'data_retirada', 'horario_retirada', 'data_prevista_devolucao', 'horario_prevista_devolucao', 'data_devolucao', 'horario_devolucao', 'status'),
    extra=5,
    can_delete=True
)